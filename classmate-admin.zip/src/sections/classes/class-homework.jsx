import { Typography } from "@mui/material"

export const ClassHomeWork = (props) => {
  <Typography>Class Homework</Typography>
}