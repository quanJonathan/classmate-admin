export enum userStateEnum {
  active = 'active',
  banned = 'banned',
  activated = 'activated',
  notActivated = 'not-activated',
}
